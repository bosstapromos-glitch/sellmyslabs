<script>
  export let query = "";
</script>

<input type="search" aria-label="Search cards by name" placeholder="Search cards by name" bind:value={query} />
