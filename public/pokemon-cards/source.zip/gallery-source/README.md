# Pokémon Cards Holographic effect in CSS

## Run this updated copy

Use Node.js 22.12+ on the 22.x line, or Node.js 24+. Run `npm ci` and then `npm run dev` in this folder. For a production build, run `npm run build` and serve the contents of `dist/` from the gallery directory.

This November 18, 2026 revision updates the build dependencies and removes Google Analytics and remote fonts. The single-page gallery combines the featured cards with a bundled snapshot of 3,529 English Sword & Shield cards. All 3,540 unique cards can be browsed or searched locally. [Search catalog source](https://github.com/PokemonTCG/pokemon-tcg-data/tree/90f27d0e14cefe48ccb2b8922a7a356b2fcf0072)

### Use a card in Svelte

Load the card stylesheets listed in `index.html` in their original order and keep `public/img/` alongside the published `css/` directory. Pass the card metadata to the component, for example:

```svelte
<script>
  import Card from "./lib/components/CardProxy.svelte";
</script>

<Card id="swsh12pt5-160" name="Pikachu" set="swsh12pt5" number="160"
  types={["Lightning"]} subtypes={["Basic"]} supertype="Pokémon" rarity="Rare Secret" />
```

Card faces, card backs and card-specific foils and masks load from the original image hosts. To supply your own assets, pass absolute or root-relative URLs in `img`, `back`, `foil` and `mask`. To use a mirror of the original foil directory, set `VITE_CDN` to its base URL before building. Search requires no API key.

This is a repository holder for the Pokemon Cards CSS Holographic effect.  

| <img src="https://github.com/user-attachments/assets/ca493541-57bb-48c3-b40c-925f7203a933" width=80> | As seen on [css-tricks.com](https://css-tricks.com/holographic-trading-card-effect/) and [codepen](https://codepen.io/simeydotme/pen/abYWJdX) 
| --: | :-- |
| [<img src="https://github.com/user-attachments/assets/fd862cc7-2f30-4a35-9dbc-778edcc369f3" width=80>](https://poke-holo.simey.me/) | Demo running @ https://poke-holo.simey.me/   |
| [<img src="https://github.com/user-attachments/assets/f1c9d376-0948-4b96-826e-f016e6584736" width=80><img src="https://github.com/user-attachments/assets/8137f0c8-6bc2-4f22-90c9-03cb8332b6f1" width=25>](https://poke-151.simey.me/) | 151 version @ https://poke-151.simey.me/ ⭐ |

<br><br>

-----

> [!TIP]
> I've published a component which can help with getting you a similar effect to this, without much effort;  
> https://github.com/simeydotme/hover-tilt 

---

### A collection of advanced CSS styles, applied with SvelteJS.
Uses CSS Transforms, Gradients, Blend-modes and Filters to simulate the various Holofoil effects found
in the Sword and Shield era of Pokemon Trading Cards.

<img src="public/pokemon-cards-demo.gif" />



---

> [!NOTE]
> Please [read `#issues/19` before asking / requesting any help](https://github.com/simeydotme/pokemon-cards-css/issues/19) or advice on the Project.  
Thank you.


---

#### support / tip  
If you think this is super cool, or useful, and want to donate a little, then you are also super cool!

|  |  |         |
|--|--:|---------|
| <img src="https://user-images.githubusercontent.com/2817396/149629283-6002944f-9253-4e35-917d-89b476deae4e.png" width=20> | [![£1 One Pound tip](https://user-images.githubusercontent.com/2817396/149629980-08b9a952-bd6a-4c23-be78-05e3fd534352.png)](https://www.paypal.com/paypalme/simey/1) | [£1 tip](https://www.paypal.com/paypalme/simey/1) |
| <img src="https://user-images.githubusercontent.com/2817396/149629283-6002944f-9253-4e35-917d-89b476deae4e.png" width=20> | [![£5 Five Pounds tip](https://user-images.githubusercontent.com/2817396/149629994-3a99770c-d333-46e7-9818-ab6b18ad0202.png)](https://www.paypal.com/paypalme/simey/5) | [£5 tip](https://www.paypal.com/paypalme/simey/5) |
| <img src="https://user-images.githubusercontent.com/2817396/149629283-6002944f-9253-4e35-917d-89b476deae4e.png" width=20> | [![£10 Ten Pounds tip](https://user-images.githubusercontent.com/2817396/149630000-95aa4234-ff67-4e7c-a7f4-ffd52f25e6d8.png)](https://www.paypal.com/paypalme/simey/10) | [£10 tip](https://www.paypal.com/paypalme/simey/10) |





---
#### attribution

<sub>- Galaxy Holo from [aschefield101](https://www.deviantart.com/aschefield101/art/HoloSheet-2012-313543843)</sub>  
<sub>- Some backgrounds from [Vecteezy](https://www.vecteezy.com/free-photos)</sub>
