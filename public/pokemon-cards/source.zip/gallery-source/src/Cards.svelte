<script>
  import { onDestroy } from "svelte";
  import Card from "./lib/components/CardProxy.svelte";

  export let cards;
  let visible = new Set();
  let observer;

  function watchSlot(node) {
    observer ??= new IntersectionObserver(entries => {
      const next = new Set(visible);
      for (const { target, isIntersecting } of entries) {
        if (isIntersecting && target.isConnected) next.add(target.dataset.id);
        else next.delete(target.dataset.id);
      }
      visible = next;
    }, { rootMargin: "600px 0px" });
    observer.observe(node);
    return { destroy() { observer.unobserve(node); visible.delete(node.dataset.id); } };
  }

  onDestroy(() => observer?.disconnect());
</script>

<div class="card-grid">
  {#each cards as card (card.id)}
    <div class="slot" data-id={card.id} use:watchSlot>
      {#if visible.has(card.id)}
        <Card id={card.id} name={card.name} set={card.set} number={card.number}
          types={card.types} subtypes={card.subtypes} supertype={card.supertype}
          rarity={card.rarity} isReverse={card.isReverse} img={card.images?.large}
          foil={card.plain ? false : undefined} mask={card.plain ? false : undefined} />
      {/if}
    </div>
  {/each}
</div>

<style>
  .card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(min(100%, 185px), 1fr));
    gap: clamp(12px, 1.6vw, 24px);
  }
  .slot {
    aspect-ratio: var(--card-aspect);
    min-width: 0;
    border-radius: var(--card-radius);
    background: #292e37;
  }
  @media (max-width: 520px) {
    .card-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  }
</style>
