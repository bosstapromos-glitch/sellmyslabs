<script>
  import { onMount } from "svelte";
  import Cards from "./Cards.svelte";
  import Search from "./Search.svelte";

  let query = "";
  let cards = [];
  let status = "loading";

  async function loadCards() {
    status = "loading";
    try {
      const [featured, catalog] = await Promise.all(["cards", "search-cards"].map(async name => {
        const response = await fetch(import.meta.env.BASE_URL + "data/" + name + ".json");
        if (!response.ok) throw new Error("Card catalog unavailable");
        return response.json();
      }));
      const featuredIds = new Set(featured.map(card => card.id));
      cards = [...featured, ...catalog.filter(card => !featuredIds.has(card.id))];
      status = "ready";
    } catch {
      status = "error";
    }
  }

  onMount(loadCards);
  $: term = query.trim().toLowerCase();
  $: matches = term ? cards.filter(card => card.name.toLowerCase().includes(term)) : cards;
</script>

<main id="top">
  <header>
    <div>
      <a class="site-return" href="/">← SellMySlabs</a>
      <h1>Pokémon cards</h1>
      <p class="byline">Holo effects by <a href="https://github.com/simeydotme/pokemon-cards-css">Simon Goellner</a> · <a href={import.meta.env.BASE_URL + "source.zip"} download>Gallery source</a></p>
    </div>
    <Search bind:query />
  </header>

  {#if status === "ready"}
    <p class="count" role="status">{matches.length.toLocaleString("en-US")} {matches.length === 1 ? "card" : "cards"}</p>
    {#if matches.length}
      <Cards cards={matches} />
      <a class="top-link" href="#top">Back to top ↑</a>
    {:else}
      <p>No cards match “{query}”. <button on:click={() => query = ""}>Clear search</button></p>
    {/if}
  {:else if status === "error"}
    <p role="alert">Couldn’t load the cards. <button on:click={loadCards}>Try again</button></p>
  {:else}
    <p role="status">Loading cards…</p>
  {/if}
</main>
